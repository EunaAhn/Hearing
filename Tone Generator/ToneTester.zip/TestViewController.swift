//
//  TestViewController.swift
//  Tone Generator
//
//  Created by Siseong Ahn on 2022/11/13.
//

import UIKit
import AVFoundation

class TestViewController: UIViewController {

    @IBOutlet weak var labelFrequency: UILabel!
    
    var engine: AVAudioEngine!
    var tone: AVTonePlayerUnit!
    let frequency = [250.0, 500.0, 1000.0, 1500.0, 2000.0, 3000.0, 4000.0, 6000.0, 8000.0]
    var testResult:[Int] = []
    var decibel = 0
    var testIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.labelFrequency.text = ""
        
        //AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        //[audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSession.Category.playback)
        }
        catch {
            debugPrint("error set category!")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        

    }
    
    @IBAction func actionStart(_ sender: Any) {
        self.labelFrequency.text = "\(frequency[testIndex]) Hz"
        startTest()
    }
    
    @IBAction func actionYes(_ sender: Any) {
        stopTest()
        if (decibel > 90) {
            //testResult.append(decibel)
            testIndex = testIndex + 1
            decibel = 0
        }
        else {
            decibel = decibel + 10
        }
        // TODO: timer 3초
        
    }


    func startTest() {
        tone = AVTonePlayerUnit()
        tone.frequency = frequency[testIndex]
        tone.decibel = decibel
        
        let format = AVAudioFormat(standardFormatWithSampleRate: tone.sampleRate, channels: 1)
        debugPrint(format?.sampleRate ?? "format nil")
        engine = AVAudioEngine()
        engine.attach(tone)
        let mixer = engine.mainMixerNode
        engine.connect(tone, to: mixer, format: format)
        do {
            try engine.start()
        } catch let error as NSError {
            debugPrint(error)
        }
        tone.preparePlaying()
        tone.play()
        engine.mainMixerNode.volume = 1.0
    }
    
    func stopTest() {
        engine.mainMixerNode.volume = 0.0
        engine.stop()
        engine.disconnectNodeOutput(engine.mainMixerNode)
        engine.reset()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
